document.addEventListener('DOMContentLoaded',function(){
Typed.new('.element',{
strings: ["(P.M.E.C) PRESENTS"],
typespeed:0
});

});


 /* var typed = new Typed('.element', {
    stringsElement: '#typed-strings'
  });
*/