document.addEventListener('DOMContentLoaded',function(){
Typed.new('.highlight',{
strings: ["EXUBERANCE-2K18"],
typespeed:0
});

});


 /* var typed = new Typed('.element', {
    stringsElement: '#typed-strings'
  });
*/