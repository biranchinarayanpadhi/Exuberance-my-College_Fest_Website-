document.addEventListener('DOMContentLoaded',function(){
Typed.new('.exub',{
strings: ["Exuberance-2k18"],
typespeed:0
});

});


 /* var typed = new Typed('.element', {
    stringsElement: '#typed-strings'
  });
*/